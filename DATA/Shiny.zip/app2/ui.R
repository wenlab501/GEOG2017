library(shiny)
shinyUI(fluidPage(
    titlePanel("Spatial Analysis App 2"),

    sidebarLayout(
        sidebarPanel(
            sliderInput("bins","Number of bins:",min = 3,max = 7,value = 5),
            checkboxGroupInput("county","County",c("Taipei City"="63000","New Taipei City"="65000","Keelung City"="10017"),c(63000,65000,10017))
        ),

        mainPanel(
            tabsetPanel(
                tabPanel("Histogram", plotOutput("histPlot")),
                tabPanel("Map", tmapOutput("map"))
            )
        )
    )
))
