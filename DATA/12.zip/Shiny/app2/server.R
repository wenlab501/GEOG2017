library(shiny);library(sf);library(tmap)

TW=st_read("GTMA.shp")

shinyServer(function(input, output) {

    output$histPlot=renderPlot({
        TWx  = TW[TW$COUNTY_ID%in%input$county,]
        x    = TWx$Cases
        bins = seq(min(x), max(x), length.out = input$bins + 1)
        hist(x, breaks = bins, col = 'darkgray', border = 'white',xlab="Cases")
    })

    output$map=renderTmap({
        TWx  = TW[TW$COUNTY_ID%in%input$county,]
        qtm(TWx,'Cases')
    })

})
