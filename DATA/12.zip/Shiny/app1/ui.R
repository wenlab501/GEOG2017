library(shiny)
shinyUI(fluidPage(
    titlePanel("Spatial Analysis App 1"),

    sidebarLayout(
        sidebarPanel(
            sliderInput("bins","Number of bins:",min = 3,max = 7,value = 5)
        ),

        mainPanel(
            plotOutput("histPlot")
        )
    )
))
