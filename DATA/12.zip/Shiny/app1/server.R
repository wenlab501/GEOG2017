library(shiny);library(sf);library(tmap)

    TW=st_read("GTMA.shp")
    
    shinyServer(function(input, output) {
    
        output$histPlot=renderPlot({
            x    = TW$Cases
            bins = seq(min(x), max(x), length.out = input$bins + 1)
            hist(x, breaks = bins, col = 'darkgray', border = 'white',xlab="Cases")
        })
    
    })
